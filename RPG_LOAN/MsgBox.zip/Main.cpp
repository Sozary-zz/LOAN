#include "Game.h"

int main() {

	Game app;
	app.run();

	return 0;
}